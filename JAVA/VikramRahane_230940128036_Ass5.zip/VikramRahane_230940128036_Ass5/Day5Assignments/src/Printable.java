
public interface Printable {
	public void printDetails();

}
