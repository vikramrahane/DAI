import com.cdac.pack1.*;
import com.cdac.pack2.*;
public class Ass4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new  Student(1, "Vikram");
		Student s2=new  Student(2, "Prada");
		s1.display();
		s2.display();
		Batch b1=new Batch("DAI", 40);
		Batch b2=new Batch("DBDA", 60);
		b1.display();
		b2.display();
	}

}
