
public class Ass_2_3 {

		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student_Ass_2_3 s1=new Student_Ass_2_3();
		Student_Ass_2_3 s2=new Student_Ass_2_3("Prada", 99);
		Student_Ass_2_3 s3=new Student_Ass_2_3("Tejas", 89);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}

}
