
public class Ass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UtilityList slist=new UtilityList();
		slist.createList();
		slist.printList();
	}

}
