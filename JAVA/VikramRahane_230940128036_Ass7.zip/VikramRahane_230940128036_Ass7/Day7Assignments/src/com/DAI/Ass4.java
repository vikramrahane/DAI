package com.DAI;

public class Ass4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UtilityReport rep=new UtilityReport();
		rep.createMap();
		rep.printMap();
	}

}
