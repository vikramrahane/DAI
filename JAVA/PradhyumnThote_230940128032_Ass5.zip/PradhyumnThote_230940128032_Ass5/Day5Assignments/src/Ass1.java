
public class Ass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CktPlayer ck=new CktPlayer("Prada", 4000);
		FtPlayer fp=new FtPlayer("Vicky",30);
		ck.printDetails();
		fp.printDetails();
	}

}
