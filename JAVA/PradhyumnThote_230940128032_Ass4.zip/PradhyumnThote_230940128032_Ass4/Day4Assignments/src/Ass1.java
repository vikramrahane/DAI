
public class Ass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student("Vikram", 30, 04, 1991);
		Student s2=new Student("Prada", 14, 11, 1998);
		s1.show();
		s2.show();
	}

}
