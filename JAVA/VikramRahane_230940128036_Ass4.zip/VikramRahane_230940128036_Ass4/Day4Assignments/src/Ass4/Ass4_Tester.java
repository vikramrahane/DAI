package Ass4;

public class Ass4_Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m=new Manager(101, "Vikram", 1000);
		m.show();
		MarketingExe me=new MarketingExe(201, "Tejas", 500, 60);
		me.show();
				
	}

}
